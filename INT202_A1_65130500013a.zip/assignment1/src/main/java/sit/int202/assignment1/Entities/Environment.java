package sit.int202.assignment1.Entities;

public class Environment {
    public static final String UNIT_NAME = "classic-models";
}
