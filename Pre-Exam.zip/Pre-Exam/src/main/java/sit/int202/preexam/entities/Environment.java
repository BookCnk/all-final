package sit.int202.preexam.entities;
public class Environment {
    public static final String PU_NAME = "classic-models";
}
